/** Automatically generated file. DO NOT MODIFY */
package me.mren.timemachine;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}